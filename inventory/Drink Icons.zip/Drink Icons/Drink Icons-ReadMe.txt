Credit: Molly "Cougarmint" Willits
Created by hand using Photoshop Educational Edition 6.0.

Licence: CC-BY 3.0.

Free Commercial Use: Yes
Free Personal Use: Yes

Included in this Pack:
Drink_IconSet.png (RPG Maker VX Ace Ready)
Drinkicon_scrap.png (To plug in a previously made RPG Maker VX Ace Icon set)
bottle_base.png -- Create your own drink.

Drinks Folder:
AppleJuice.png
CherryPop.png
GrapeJuice.png
Lemonade.png
LimeSoda.png
Milk.png
OrangeJuice.png
RaspberryPop.png
SodaPop.png
StrawberryPop.png
Water.png
WatermelonPop.png

Donations: Not needed, but appreciated. Contact me if you'd like to make a donation.